# Checklist de pruebas

- El servidor inicia con `npm start`.
- `/api/health` responde `running`.
- El catálogo muestra productos.
- El carrito suma correctamente.
- Checkout bloquea email inválido.
- PayPal muestra botones con Client ID válido.
- La orden se crea desde `/api/paypal/orders`.
- La captura cambia pedido a `COMPLETED`.
- El panel admin muestra pedidos con `ADMIN_KEY`.
