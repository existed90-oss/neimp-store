# Flujo de pedido

1. El usuario agrega productos.
2. El navegador guarda el carrito en `localStorage`.
3. El checkout envía solo `id` y `quantity`.
4. El servidor lee `products.json` y calcula el precio real.
5. El servidor crea la orden en PayPal.
6. El usuario aprueba en PayPal.
7. El servidor captura la orden.
8. El pedido se guarda en `orders.json`.
