# Cambiar productos

Edita `src/data/products.json`.

Campos importantes:

- `id`: identificador único.
- `sku`: código del producto.
- `name`: nombre visible.
- `price`: precio como texto con dos decimales.
- `currency`: debe coincidir con `STORE_CURRENCY`.
- `stock`: cantidad disponible.
- `type`: `digital` o `physical`.
