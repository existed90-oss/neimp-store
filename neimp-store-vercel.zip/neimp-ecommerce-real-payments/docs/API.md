# API

- `GET /api/config`
- `GET /api/products`
- `GET /api/products/:id`
- `POST /api/cart/quote`
- `POST /api/paypal/orders`
- `POST /api/paypal/orders/:orderID/capture`
- `GET /api/orders/:orderID`
- `GET /api/admin/orders?key=ADMIN_KEY`
- `POST /api/contact`
