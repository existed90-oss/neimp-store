# Notas legales

Antes de vender públicamente, revisa con un adulto responsable o asesor:

- Políticas de devolución.
- Aviso de privacidad.
- Impuestos.
- Entrega de productos digitales o físicos.
- Soporte al cliente.
