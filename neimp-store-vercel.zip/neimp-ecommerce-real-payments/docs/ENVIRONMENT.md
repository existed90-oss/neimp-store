# Variables de entorno

`PAYPAL_CLIENT_ID` es público y se usa para cargar el SDK en el navegador.

`PAYPAL_CLIENT_SECRET` es privado y solo se usa en el servidor.

`PAYPAL_ENV` puede ser `sandbox` o `live`.
