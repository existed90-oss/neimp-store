# Changelog

## 1.0.0

- Catálogo de productos.
- Producto de prueba de 1 MXN.
- Carrito con localStorage.
- Checkout con PayPal Buttons.
- Creación de órdenes PayPal desde servidor.
- Captura de órdenes PayPal desde servidor.
- Registro local de pedidos.
- Panel admin básico.
- Páginas legales y de contacto.
