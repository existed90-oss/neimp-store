# Seguridad

Este proyecto evita manejar datos sensibles de tarjetas. Todo el pago se realiza mediante PayPal.

## Buenas prácticas usadas

- El precio se calcula en el servidor.
- El secreto de PayPal solo se usa en el servidor.
- El carrito se valida antes de crear una orden.
- Se guardan pedidos con estado `CREATED` o `COMPLETED`.
- Hay cabeceras HTTP básicas de seguridad.

## Recomendaciones antes de publicar

- Cambiar `ADMIN_KEY`.
- Usar HTTPS.
- Proteger el panel admin con login real si la tienda crece.
- Revisar impuestos, envíos y devoluciones.
- Mantener backups de `src/data/orders.json`.
