import { ORDERS_FILE, MESSAGES_FILE } from '../src/config/paths.js';
import { backupJson, writeJson } from '../src/utils/fileDb.js';

await backupJson(ORDERS_FILE);
await backupJson(MESSAGES_FILE);
await writeJson(ORDERS_FILE, []);
await writeJson(MESSAGES_FILE, []);
console.log('Pedidos y mensajes reiniciados. Se creó backup si existía información previa.');
