import { sendJson } from '../utils/http.js';

export function apiNotFound(res) {
  sendJson(res, 404, {
    ok: false,
    error: 'Ruta API no encontrada.'
  });
}
