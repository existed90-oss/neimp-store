export function cleanString(value, max = 120) {
  return String(value || '').trim().slice(0, max);
}

export function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
}

export function normalizeQuantity(value) {
  const qty = Number.parseInt(value, 10);
  if (!Number.isFinite(qty) || qty < 1) return 1;
  if (qty > 99) return 99;
  return qty;
}

export function validateCartInput(cart) {
  if (!Array.isArray(cart) || cart.length === 0) {
    throw new Error('El carrito está vacío.');
  }
  return cart.map((item) => ({
    id: cleanString(item.id, 80),
    quantity: normalizeQuantity(item.quantity)
  }));
}
