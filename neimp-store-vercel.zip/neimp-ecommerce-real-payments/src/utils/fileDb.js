import { readFile, writeFile, rename, copyFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

export async function readJson(file, fallback) {
  try {
    const text = await readFile(file, 'utf8');
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

export async function writeJson(file, data) {
  const tempFile = `${file}.tmp`;
  await writeFile(tempFile, JSON.stringify(data, null, 2), 'utf8');
  await rename(tempFile, file);
}

export async function backupJson(file) {
  if (!existsSync(file)) return;
  await copyFile(file, `${file.replace(/\.json$/, '')}.backup.json`);
}
