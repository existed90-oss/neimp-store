import { randomBytes } from 'node:crypto';

export function createId(prefix = 'id') {
  const stamp = Date.now().toString(36);
  const random = randomBytes(6).toString('hex');
  return `${prefix}_${stamp}_${random}`;
}
