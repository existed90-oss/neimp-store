export function toCents(value) {
  const normalized = String(value).replace(',', '.');
  const [whole = '0', decimals = ''] = normalized.split('.');
  return Number(whole) * 100 + Number((decimals + '00').slice(0, 2));
}

export function fromCents(cents) {
  return (Number(cents) / 100).toFixed(2);
}

export function formatMoney(value, currency = 'MXN') {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency
  }).format(Number(value));
}

export function addMoney(items) {
  return fromCents(items.reduce((sum, item) => sum + toCents(item.price) * item.quantity, 0));
}
