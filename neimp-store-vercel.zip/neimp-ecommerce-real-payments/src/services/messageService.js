import { MESSAGES_FILE } from '../config/paths.js';
import { readJson, writeJson } from '../utils/fileDb.js';
import { createId } from '../utils/id.js';
import { cleanString, isEmail } from '../utils/validation.js';
import { getDatabase } from './database.js';

export async function saveMessage(input) {
  const name = cleanString(input.name, 80);
  const email = cleanString(input.email, 120);
  const message = cleanString(input.message, 800);
  if (!name) throw new Error('Escribe tu nombre.');
  if (!isEmail(email)) throw new Error('Escribe un email válido.');
  if (!message) throw new Error('Escribe un mensaje.');
  const item = { id: createId('msg'), name, email, message, createdAt: new Date().toISOString() };
  const sql = getDatabase();
  if (sql) {
    await sql`INSERT INTO neimp_messages (id, message_data) VALUES (${item.id}, ${JSON.stringify(item)}::jsonb)`;
  } else {
    const messages = await readJson(MESSAGES_FILE, []);
    messages.unshift(item);
    await writeJson(MESSAGES_FILE, messages);
  }
  return item;
}
