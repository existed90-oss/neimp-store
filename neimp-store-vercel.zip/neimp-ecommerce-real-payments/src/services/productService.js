import { PRODUCTS_FILE } from '../config/paths.js';
import { readJson } from '../utils/fileDb.js';
import { validateCartInput } from '../utils/validation.js';
import { addMoney } from '../utils/money.js';
import { env } from '../config/env.js';

export async function listProducts() {
  return await readJson(PRODUCTS_FILE, []);
}

export async function getProductById(id) {
  const products = await listProducts();
  return products.find((product) => product.id === id) || null;
}

export async function buildServerCart(cartInput) {
  const products = await listProducts();
  const validInput = validateCartInput(cartInput);
  const items = [];

  for (const input of validInput) {
    const product = products.find((candidate) => candidate.id === input.id);
    if (!product) throw new Error(`Producto no encontrado: ${input.id}`);
    if (input.quantity > product.stock) throw new Error(`Stock insuficiente para ${product.name}`);
    if (product.currency !== env.currency) throw new Error(`Moneda no compatible para ${product.name}`);

    items.push({
      id: product.id,
      sku: product.sku,
      name: product.name,
      price: product.price,
      currency: product.currency,
      quantity: input.quantity,
      image: product.image,
      type: product.type
    });
  }

  const total = addMoney(items);
  return {
    items,
    total,
    currency: env.currency
  };
}
