import { neon } from '@neondatabase/serverless';

let client;
export function getDatabase() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    if (process.env.VERCEL) throw new Error('Falta configurar DATABASE_URL en Vercel.');
    return null;
  }
  if (!client) client = neon(url);
  return client;
}
