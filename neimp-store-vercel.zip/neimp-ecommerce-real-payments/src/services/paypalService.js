import { env, isPayPalConfigured } from '../config/env.js';
import { getPayPalBaseUrl } from '../config/paypal.js';
import { logError } from '../utils/logger.js';

async function handlePayPalResponse(response) {
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }

  if (!response.ok) {
    const message = data?.message || data?.error_description || 'Error de PayPal';
    const error = new Error(message);
    error.statusCode = response.status;
    error.paypal = data;
    throw error;
  }
  return data;
}

export async function generateAccessToken() {
  if (!isPayPalConfigured()) {
    throw new Error('Faltan PAYPAL_CLIENT_ID y PAYPAL_CLIENT_SECRET en .env');
  }

  const auth = Buffer.from(`${env.paypalClientId}:${env.paypalClientSecret}`).toString('base64');
  const response = await fetch(`${getPayPalBaseUrl()}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials'
  });
  const data = await handlePayPalResponse(response);
  return data.access_token;
}

export async function createPayPalOrder(cart) {
  try {
    const accessToken = await generateAccessToken();
    const response = await fetch(`${getPayPalBaseUrl()}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
        'PayPal-Request-Id': `neimp-${Date.now()}`
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [
          {
            description: 'Compra en Neimp Store',
            amount: {
              currency_code: cart.currency,
              value: cart.total,
              breakdown: {
                item_total: {
                  currency_code: cart.currency,
                  value: cart.total
                }
              }
            },
            items: cart.items.map((item) => ({
              name: item.name,
              sku: item.sku,
              unit_amount: {
                currency_code: item.currency,
                value: item.price
              },
              quantity: String(item.quantity),
              category: item.type === 'digital' ? 'DIGITAL_GOODS' : 'PHYSICAL_GOODS'
            }))
          }
        ],
        application_context: {
          brand_name: env.storeName,
          shipping_preference: 'NO_SHIPPING',
          user_action: 'PAY_NOW',
          return_url: `${env.publicBaseUrl}/success.html`,
          cancel_url: `${env.publicBaseUrl}/cancel.html`
        }
      })
    });
    return await handlePayPalResponse(response);
  } catch (error) {
    logError('Error creando orden PayPal', error);
    throw error;
  }
}

export async function capturePayPalOrder(orderID) {
  try {
    const accessToken = await generateAccessToken();
    const response = await fetch(`${getPayPalBaseUrl()}/v2/checkout/orders/${encodeURIComponent(orderID)}/capture`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`
      }
    });
    return await handlePayPalResponse(response);
  } catch (error) {
    logError('Error capturando orden PayPal', error);
    throw error;
  }
}
