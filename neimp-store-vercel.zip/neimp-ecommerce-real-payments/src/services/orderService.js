import { ORDERS_FILE } from '../config/paths.js';
import { readJson, writeJson } from '../utils/fileDb.js';
import { createId } from '../utils/id.js';
import { getDatabase } from './database.js';

export async function listOrders() {
  const sql = getDatabase();
  if (!sql) return await readJson(ORDERS_FILE, []);
  const rows = await sql`SELECT order_data FROM neimp_orders ORDER BY created_at DESC`;
  return rows.map((row) => row.order_data);
}

export async function createLocalOrder({ paypalOrderId, cart, customer }) {
  const order = {
    id: createId('order'), paypalOrderId, status: 'CREATED', cart, customer,
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), capture: null
  };
  const sql = getDatabase();
  if (sql) {
    await sql`INSERT INTO neimp_orders (paypal_order_id, order_data) VALUES (${paypalOrderId}, ${JSON.stringify(order)}::jsonb) ON CONFLICT (paypal_order_id) DO NOTHING`;
  } else {
    const orders = await listOrders();
    orders.unshift(order);
    await writeJson(ORDERS_FILE, orders);
  }
  return order;
}

export async function updateOrderCapture(paypalOrderId, capture) {
  const sql = getDatabase();
  if (sql) {
    const rows = await sql`SELECT order_data FROM neimp_orders WHERE paypal_order_id = ${paypalOrderId} LIMIT 1`;
    const previous = rows[0]?.order_data;
    const order = previous ? {
      ...previous, status: capture?.status || 'UNKNOWN', capture,
      updatedAt: new Date().toISOString()
    } : {
      id: createId('order'), paypalOrderId, status: capture?.status || 'UNKNOWN',
      cart: null, customer: null, createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(), capture
    };
    await sql`INSERT INTO neimp_orders (paypal_order_id, order_data) VALUES (${paypalOrderId}, ${JSON.stringify(order)}::jsonb) ON CONFLICT (paypal_order_id) DO UPDATE SET order_data = EXCLUDED.order_data`;
    return order;
  }

  const orders = await listOrders();
  const index = orders.findIndex((order) => order.paypalOrderId === paypalOrderId);
  if (index === -1) {
    const order = { id: createId('order'), paypalOrderId, status: capture?.status || 'UNKNOWN', cart: null, customer: null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), capture };
    orders.unshift(order);
    await writeJson(ORDERS_FILE, orders);
    return order;
  }
  orders[index] = { ...orders[index], status: capture?.status || 'UNKNOWN', capture, updatedAt: new Date().toISOString() };
  await writeJson(ORDERS_FILE, orders);
  return orders[index];
}

export async function getOrderByPayPalId(paypalOrderId) {
  const sql = getDatabase();
  if (sql) {
    const rows = await sql`SELECT order_data FROM neimp_orders WHERE paypal_order_id = ${paypalOrderId} LIMIT 1`;
    return rows[0]?.order_data || null;
  }
  const orders = await listOrders();
  return orders.find((order) => order.paypalOrderId === paypalOrderId) || null;
}
