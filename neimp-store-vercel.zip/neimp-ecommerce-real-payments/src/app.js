import http from 'node:http';
import { env } from './config/env.js';
import { applySecurityHeaders } from './middleware/securityHeaders.js';
import { routeApi } from './routes/apiRouter.js';
import { routeStatic } from './routes/staticRouter.js';
import { logError, logInfo } from './utils/logger.js';
import { sendJson } from './utils/http.js';

export function createServer() {
  return http.createServer(async (req, res) => {
    applySecurityHeaders(res);

    try {
      if (req.url.startsWith('/api/')) {
        await routeApi(req, res);
      } else {
        await routeStatic(req, res);
      }
    } catch (error) {
      logError('Error general del servidor', error);
      sendJson(res, 500, { ok: false, error: 'Error interno del servidor.' });
    }
  });
}

export function startServer() {
  const server = createServer();
  server.listen(env.port, () => {
    logInfo(`${env.storeName} funcionando en http://localhost:${env.port}`, {
      paypalEnv: env.paypalEnv,
      currency: env.currency
    });
  });
  return server;
}
