import { serveStatic } from '../utils/http.js';

export async function routeStatic(req, res) {
  return serveStatic(req, res);
}
