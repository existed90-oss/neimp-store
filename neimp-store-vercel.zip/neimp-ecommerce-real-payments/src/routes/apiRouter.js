import { getPath, sendJson } from '../utils/http.js';
import { apiNotFound } from '../middleware/notFound.js';
import { getProducts, getProduct } from '../controllers/productController.js';
import { quoteCart } from '../controllers/cartController.js';
import { getPublicConfig, createOrder, captureOrder } from '../controllers/paypalController.js';
import { getOrder } from '../controllers/orderController.js';
import { listAdminOrders } from '../controllers/adminController.js';
import { createContactMessage } from '../controllers/contactController.js';

export async function routeApi(req, res) {
  const path = getPath(req);
  const method = req.method.toUpperCase();

  if (method === 'GET' && path === '/api/health') {
    return sendJson(res, 200, { ok: true, status: 'running' });
  }

  if (method === 'GET' && path === '/api/config') return getPublicConfig(req, res);
  if (method === 'GET' && path === '/api/products') return getProducts(req, res);

  const productMatch = path.match(/^\/api\/products\/([^/]+)$/);
  if (method === 'GET' && productMatch) return getProduct(req, res, productMatch[1]);

  if (method === 'POST' && path === '/api/cart/quote') return quoteCart(req, res);
  if (method === 'POST' && path === '/api/paypal/orders') return createOrder(req, res);

  const captureMatch = path.match(/^\/api\/paypal\/orders\/([^/]+)\/capture$/);
  if (method === 'POST' && captureMatch) return captureOrder(req, res, captureMatch[1]);

  const orderMatch = path.match(/^\/api\/orders\/([^/]+)$/);
  if (method === 'GET' && orderMatch) return getOrder(req, res, orderMatch[1]);

  if (method === 'GET' && path === '/api/admin/orders') return listAdminOrders(req, res);
  if (method === 'POST' && path === '/api/contact') return createContactMessage(req, res);

  return apiNotFound(res);
}
