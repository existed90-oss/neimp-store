import { env, isPayPalConfigured } from '../config/env.js';
import { getPayPalSdkModeLabel } from '../config/paypal.js';
import { buildServerCart } from '../services/productService.js';
import { createPayPalOrder, capturePayPalOrder } from '../services/paypalService.js';
import { createLocalOrder, updateOrderCapture } from '../services/orderService.js';
import { readJsonBody } from '../middleware/jsonBody.js';
import { sendJson } from '../utils/http.js';
import { cleanString, isEmail } from '../utils/validation.js';

export function getPublicConfig(req, res) {
  sendJson(res, 200, {
    ok: true,
    storeName: env.storeName,
    currency: env.currency,
    paypalClientId: env.paypalClientId,
    paypalMode: getPayPalSdkModeLabel(),
    paypalConfigured: isPayPalConfigured()
  });
}

export async function createOrder(req, res) {
  try {
    const body = await readJsonBody(req);
    const cart = await buildServerCart(body.cart);
    const customer = {
      name: cleanString(body.customer?.name, 80),
      email: cleanString(body.customer?.email, 120)
    };

    if (!customer.name) throw new Error('Escribe tu nombre.');
    if (!isEmail(customer.email)) throw new Error('Escribe un email válido.');

    const paypalOrder = await createPayPalOrder(cart);
    await createLocalOrder({ paypalOrderId: paypalOrder.id, cart, customer });
    sendJson(res, 201, { ok: true, id: paypalOrder.id, paypalOrder });
  } catch (error) {
    sendJson(res, error.statusCode || 400, {
      ok: false,
      error: error.message,
      paypal: error.paypal || null
    });
  }
}

export async function captureOrder(req, res, orderID) {
  try {
    const capture = await capturePayPalOrder(orderID);
    const localOrder = await updateOrderCapture(orderID, capture);
    sendJson(res, 200, { ok: true, capture, localOrder });
  } catch (error) {
    sendJson(res, error.statusCode || 400, {
      ok: false,
      error: error.message,
      paypal: error.paypal || null
    });
  }
}
