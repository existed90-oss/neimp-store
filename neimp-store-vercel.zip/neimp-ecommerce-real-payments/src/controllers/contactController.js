import { readJsonBody } from '../middleware/jsonBody.js';
import { saveMessage } from '../services/messageService.js';
import { sendJson } from '../utils/http.js';

export async function createContactMessage(req, res) {
  try {
    const body = await readJsonBody(req);
    const message = await saveMessage(body);
    sendJson(res, 201, { ok: true, message });
  } catch (error) {
    sendJson(res, 400, { ok: false, error: error.message });
  }
}
