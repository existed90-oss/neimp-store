import { env } from '../config/env.js';
import { listOrders } from '../services/orderService.js';
import { sendJson, getQuery } from '../utils/http.js';

export async function listAdminOrders(req, res) {
  const query = getQuery(req);
  if (query.key !== env.adminKey) {
    return sendJson(res, 401, { ok: false, error: 'Clave admin incorrecta.' });
  }

  const orders = await listOrders();
  sendJson(res, 200, { ok: true, orders });
}
