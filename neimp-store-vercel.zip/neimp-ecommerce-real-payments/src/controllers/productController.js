import { listProducts, getProductById } from '../services/productService.js';
import { sendJson } from '../utils/http.js';

export async function getProducts(req, res) {
  const products = await listProducts();
  sendJson(res, 200, { ok: true, products });
}

export async function getProduct(req, res, id) {
  const product = await getProductById(id);
  if (!product) return sendJson(res, 404, { ok: false, error: 'Producto no encontrado.' });
  sendJson(res, 200, { ok: true, product });
}
