import { getOrderByPayPalId } from '../services/orderService.js';
import { sendJson } from '../utils/http.js';

export async function getOrder(req, res, paypalOrderId) {
  const order = await getOrderByPayPalId(paypalOrderId);
  if (!order) return sendJson(res, 404, { ok: false, error: 'Pedido no encontrado.' });
  sendJson(res, 200, { ok: true, order });
}
