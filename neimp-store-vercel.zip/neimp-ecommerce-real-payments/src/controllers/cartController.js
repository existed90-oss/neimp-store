import { buildServerCart } from '../services/productService.js';
import { sendJson } from '../utils/http.js';
import { readJsonBody } from '../middleware/jsonBody.js';

export async function quoteCart(req, res) {
  try {
    const body = await readJsonBody(req);
    const quote = await buildServerCart(body.cart);
    sendJson(res, 200, { ok: true, quote });
  } catch (error) {
    sendJson(res, 400, { ok: false, error: error.message });
  }
}
