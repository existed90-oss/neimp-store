import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
export const ROOT_DIR = join(__dirname, '..', '..');
export const PUBLIC_DIR = join(ROOT_DIR, 'public');
export const DATA_DIR = join(ROOT_DIR, 'src', 'data');
export const PRODUCTS_FILE = join(DATA_DIR, 'products.json');
export const ORDERS_FILE = join(DATA_DIR, 'orders.json');
export const MESSAGES_FILE = join(DATA_DIR, 'messages.json');
