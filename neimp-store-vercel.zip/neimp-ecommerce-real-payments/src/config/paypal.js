import { env } from './env.js';

export function getPayPalBaseUrl() {
  return env.paypalEnv === 'live'
    ? 'https://api-m.paypal.com'
    : 'https://api-m.sandbox.paypal.com';
}

export function getPayPalSdkModeLabel() {
  return env.paypalEnv === 'live' ? 'LIVE' : 'SANDBOX';
}
