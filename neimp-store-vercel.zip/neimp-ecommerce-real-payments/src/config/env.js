import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT_DIR } from './paths.js';

function loadDotEnv() {
  const envPath = join(ROOT_DIR, '.env');
  if (!existsSync(envPath)) return;

  const lines = readFileSync(envPath, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
    const [key, ...rest] = trimmed.split('=');
    const value = rest.join('=').replace(/^['"]|['"]$/g, '');
    if (!process.env[key]) process.env[key] = value;
  }
}

loadDotEnv();

export const env = {
  port: Number(process.env.PORT || 3000),
  storeName: process.env.STORE_NAME || 'Neimp Store',
  currency: process.env.STORE_CURRENCY || 'MXN',
  paypalEnv: (process.env.PAYPAL_ENV || 'sandbox').toLowerCase(),
  paypalClientId: process.env.PAYPAL_CLIENT_ID || '',
  paypalClientSecret: process.env.PAYPAL_CLIENT_SECRET || '',
  adminKey: process.env.ADMIN_KEY || 'admin',
  publicBaseUrl: process.env.PUBLIC_BASE_URL || (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 'http://localhost:3000')
};

export function isPayPalConfigured() {
  return Boolean(env.paypalClientId && env.paypalClientSecret);
}
