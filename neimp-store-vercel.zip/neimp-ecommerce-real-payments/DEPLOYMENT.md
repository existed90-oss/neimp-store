# Despliegue

Este proyecto puede ejecutarse localmente con Node.js o desplegarse en Vercel.

- Para Vercel + GitHub, sigue `VERCEL_DEPLOYMENT.md`.
- Para servidor Node.js tradicional, configura las variables de `.env.example` y ejecuta `npm start`.

En Vercel configura `DATABASE_URL` con PostgreSQL compatible con Neon y ejecuta `database/schema.sql` una vez. No uses archivos JSON como almacenamiento de pedidos en producción serverless: el filesystem de las funciones no es persistente.
