# Activar pagos reales de PayPal

1. Entra a PayPal Developer.
2. Crea o abre una app REST.
3. Cambia el ambiente a **Live**.
4. Copia el **Client ID** y el **Secret**.
5. Crea un archivo `.env` usando `.env.example`.
6. Configura:

```env
PAYPAL_ENV=live
PAYPAL_CLIENT_ID=tu_client_id_live
PAYPAL_CLIENT_SECRET=tu_secret_live
STORE_CURRENCY=MXN
```

7. Reinicia el servidor.

## Comprobación

En `/checkout.html` deben aparecer botones de PayPal. Si no aparecen, revisa:

- Que `PAYPAL_CLIENT_ID` no esté vacío.
- Que estés usando una cuenta/app válida.
- Que la moneda sea compatible con tu cuenta.
- Que el sitio en producción tenga HTTPS.

## Nunca hagas esto

- No pegues el `PAYPAL_CLIENT_SECRET` en archivos dentro de `public/`.
- No cobres tarjetas manualmente.
- No guardes números de tarjeta, CVV ni datos bancarios.
