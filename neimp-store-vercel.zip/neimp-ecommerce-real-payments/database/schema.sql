CREATE TABLE IF NOT EXISTS neimp_orders (
  paypal_order_id TEXT PRIMARY KEY,
  order_data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS neimp_messages (
  id TEXT PRIMARY KEY,
  message_data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
