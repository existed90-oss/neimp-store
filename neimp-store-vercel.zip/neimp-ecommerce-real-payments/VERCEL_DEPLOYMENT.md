# Deploy en Vercel + GitHub

## 1. Subir el proyecto a GitHub

1. Crea un repositorio nuevo en GitHub (por ejemplo `neimp-store`).
2. Descomprime este proyecto y sube **el contenido de esta carpeta**, no el ZIP.
3. No subas `.env`, credenciales ni claves. `.gitignore` ya excluye `.env`.

## 2. Importar en Vercel

1. Entra a https://vercel.com/new e inicia sesión con GitHub.
2. Importa `neimp-store`.
3. Framework Preset: **Other**. Root Directory: `./`.
4. No configures Build Command ni Output Directory. Vercel sirve `public/` y ejecuta `api/[...path].js` como función Node.

## 3. Variables de entorno

En Vercel → Project → Settings → Environment Variables agrega:

- `STORE_NAME` = `Neimp Store`
- `STORE_CURRENCY` = `MXN`
- `PAYPAL_ENV` = `sandbox` para pruebas o `live` para cobros reales
- `PAYPAL_CLIENT_ID` = Client ID de la app PayPal del mismo entorno
- `PAYPAL_CLIENT_SECRET` = Secret de esa app (solo servidor)
- `ADMIN_KEY` = una contraseña larga, única y difícil de adivinar
- `PUBLIC_BASE_URL` = URL HTTPS del deployment, por ejemplo `https://tu-tienda.vercel.app` (sin `/` al final)
- `DATABASE_URL` = URL de conexión de una base de datos PostgreSQL compatible con Neon

Después de agregar o cambiar variables, crea un nuevo deployment.

## 4. Base de datos

Vercel es serverless y su sistema de archivos no es almacenamiento persistente. Este proyecto usa PostgreSQL cuando existe `DATABASE_URL` para conservar pedidos y mensajes entre ejecuciones. Ejecuta una vez el SQL de `database/schema.sql` en el editor SQL de tu base Neon.

## 5. Verificar

- Abre `https://tu-tienda.vercel.app/api/health`; debe responder `{"ok":true,"status":"running"}`.
- Abre la tienda y prueba primero con PayPal Sandbox.
- Revisa `https://tu-tienda.vercel.app/admin.html` con tu `ADMIN_KEY`.

## Importante sobre pagos reales

No cambies a `PAYPAL_ENV=live` hasta haber probado el flujo completo con Sandbox y revisado productos, precio, políticas, correo y entrega. No publiques credenciales en GitHub ni en archivos del frontend. Los pagos reales requieren credenciales LIVE válidas de PayPal.
