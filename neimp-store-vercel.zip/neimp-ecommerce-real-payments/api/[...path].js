import { EventEmitter } from 'node:events';
import { routeApi } from '../src/routes/apiRouter.js';
import { applySecurityHeaders } from '../src/middleware/securityHeaders.js';

function makeRequest(req) {
  const request = new EventEmitter();
  request.url = req.url || '/';
  request.method = req.method || 'GET';
  request.headers = req.headers || {};
  request.destroy = () => {};
  queueMicrotask(() => {
    if (req.body !== undefined && req.body !== null) {
      const body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
      request.emit('data', Buffer.from(body));
    }
    request.emit('end');
  });
  return request;
}

export default async function handler(req, res) {
  applySecurityHeaders(res);
  const headers = {};
  let statusCode = 200;
  let responseBody = '';
  const response = {
    setHeader(name, value) { headers[name] = value; },
    writeHead(status, values = {}) { statusCode = status; Object.assign(headers, values); },
    end(body = '') {
      responseBody = body;
      if (!res.headersSent) {
        for (const [name, value] of Object.entries(headers)) res.setHeader(name, value);
        res.statusCode = statusCode;
      }
      res.end(responseBody);
    }
  };

  try {
    await routeApi(makeRequest(req), response);
  } catch (error) {
    console.error('Vercel API error:', error);
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
    }
    res.end(JSON.stringify({ ok: false, error: 'Error interno del servidor.' }));
  }
}
