# Neimp Store — E-commerce con pagos reales PayPal

Este ZIP contiene una tienda funcional con más de 30 archivos: frontend, backend, carrito, producto de prueba de **$1 MXN**, checkout PayPal, captura de pago desde servidor, registro de pedidos y panel admin básico.

## Importante

El proyecto está preparado para pagos reales, pero **no puede cobrar dinero hasta que pegues tus propias credenciales LIVE de PayPal**. No se incluye ningún secreto real por seguridad.

No se guardan datos de tarjetas en tu servidor. El checkout usa PayPal, y la captura del pago se hace desde el backend con la Orders API.

## Requisitos

- Node.js 18 o superior.
- Una cuenta PayPal con una app REST creada en modo Live.
- Tus valores `PAYPAL_CLIENT_ID` y `PAYPAL_CLIENT_SECRET`.

## Cómo ejecutar

1. Descomprime el ZIP.
2. Ejecuta `npm install`.
3. Copia `.env.example` y renómbralo a `.env`.
4. Pega tus credenciales de PayPal en `.env`.
5. En terminal, entra a la carpeta del proyecto.
6. Ejecuta:

```bash
npm start
```

7. Abre:

```text
http://localhost:3000
```

## Archivos principales

- `server.js`: arranque del servidor.
- `src/app.js`: servidor HTTP y rutas.
- `src/services/paypalService.js`: crea y captura órdenes de PayPal.
- `src/data/products.json`: catálogo, incluye producto de prueba de 1 MXN.
- `public/checkout.html`: página de pago.
- `public/js/checkout.js`: botones PayPal y flujo de compra.

## Producto de prueba

El producto incluido se llama **Producto de prueba — 1 MXN** y está en `src/data/products.json`.

## Panel admin

Visita:

```text
http://localhost:3000/admin.html
```

Pega la clave `ADMIN_KEY` definida en `.env` para ver pedidos.

## Modo sandbox o real

- Para probar sin dinero real: `PAYPAL_ENV=sandbox` y credenciales sandbox.
- Para cobrar real: `PAYPAL_ENV=live` y credenciales live.

## Seguridad básica incluida

- El cliente no decide el precio: el servidor recalcula el total usando `products.json`.
- El `PAYPAL_CLIENT_SECRET` nunca se manda al navegador.
- Cabeceras de seguridad básicas.
- Validación de cantidades y productos.
- Registro local de pedidos capturados.

## Limitaciones honestas

Este proyecto no sustituye una plataforma completa como Shopify. Para vender públicamente necesitas configurar dominio, HTTPS, políticas, impuestos, logística, datos de contacto reales y cumplir reglas de PayPal y leyes locales.

## Publicar online en Vercel

El proyecto incluye una función serverless para la API, configuración `vercel.json` y persistencia PostgreSQL para pedidos y mensajes. Sigue la guía completa en **[VERCEL_DEPLOYMENT.md](./VERCEL_DEPLOYMENT.md)**. Para producción en Vercel es obligatorio configurar `DATABASE_URL` y ejecutar `database/schema.sql` en tu base de datos Neon.
