import { api } from './api.js';
import { addToCart } from './state.js';
import { money, escapeHtml } from './format.js';
import { toast } from './ui.js';

const box = document.querySelector('[data-product-detail]');

async function initProduct() {
  if (!box) return;
  const params = new URLSearchParams(location.search);
  const id = params.get('id') || 'test-1mxn';
  const { product } = await api.product(id);

  box.innerHTML = `
    <div class="hero-card">
      <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}">
    </div>
    <div>
      <span class="badge">${escapeHtml(product.category)} · SKU ${escapeHtml(product.sku)}</span>
      <h1>${escapeHtml(product.name)}</h1>
      <p>${escapeHtml(product.description)}</p>
      <p class="price" style="font-size: 32px;">${money(product.price, product.currency)}</p>
      <div class="actions">
        <input id="qty" type="number" min="1" max="99" value="1" style="width:90px;padding:13px;border-radius:14px;background:#1b1b27;color:white;border:1px solid rgba(255,255,255,.12)">
        <button class="btn primary" id="add-product">Agregar al carrito</button>
      </div>
    </div>
  `;

  document.getElementById('add-product').addEventListener('click', () => {
    addToCart(product, Number(document.getElementById('qty').value || 1));
    toast('Producto agregado al carrito.');
  });
}

initProduct().catch((error) => {
  if (box) box.innerHTML = `<p class="notice">${escapeHtml(error.message)}</p>`;
});
