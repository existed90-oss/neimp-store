import { api } from './api.js';
import { getCart, removeFromCart, updateQuantity } from './state.js';
import { money, escapeHtml } from './format.js';
import { toast } from './ui.js';

const cartBox = document.querySelector('[data-cart-box]');

async function renderCart() {
  if (!cartBox) return;
  const cart = getCart();
  if (!cart.length) {
    cartBox.innerHTML = '<div class="panel"><h2>Tu carrito está vacío</h2><p class="muted">Agrega el producto de prueba de 1 MXN para probar el checkout.</p><a class="btn primary" href="/shop.html">Ir a la tienda</a></div>';
    return;
  }

  const { quote } = await api.quote(cart);
  cartBox.innerHTML = `
    <div class="cart-list">
      ${quote.items.map((item) => `
        <div class="cart-item">
          <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}">
          <div>
            <strong>${escapeHtml(item.name)}</strong>
            <p class="muted">${escapeHtml(item.sku)}</p>
          </div>
          <div class="product-row">
            <input data-qty="${escapeHtml(item.id)}" type="number" min="1" max="99" value="${item.quantity}" style="width:75px;padding:10px;border-radius:12px;background:#1b1b27;color:white;border:1px solid rgba(255,255,255,.12)">
            <strong>${money(Number(item.price) * item.quantity, item.currency)}</strong>
            <button class="btn ghost" data-remove="${escapeHtml(item.id)}">Quitar</button>
          </div>
        </div>
      `).join('')}
    </div>
    <div class="summary">
      <h2>Total: <span class="price">${money(quote.total, quote.currency)}</span></h2>
      <a class="btn primary" href="/checkout.html">Pagar ahora</a>
    </div>
  `;
}

if (cartBox) {
  cartBox.addEventListener('click', async (event) => {
    const remove = event.target.closest('[data-remove]');
    if (!remove) return;
    removeFromCart(remove.dataset.remove);
    toast('Producto quitado.');
    await renderCart();
  });

  cartBox.addEventListener('change', async (event) => {
    const input = event.target.closest('[data-qty]');
    if (!input) return;
    updateQuantity(input.dataset.qty, input.value);
    await renderCart();
  });
}

renderCart().catch((error) => {
  if (cartBox) cartBox.innerHTML = `<p class="notice">${escapeHtml(error.message)}</p>`;
});
