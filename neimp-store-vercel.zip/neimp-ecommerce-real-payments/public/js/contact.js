import { api } from './api.js';
import { escapeHtml } from './format.js';

const form = document.querySelector('[data-contact-form]');
const result = document.querySelector('[data-contact-result]');

if (form) {
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    result.textContent = 'Enviando...';
    try {
      await api.contact(data);
      form.reset();
      result.innerHTML = '<span style="color:#32d583">Mensaje guardado correctamente.</span>';
    } catch (error) {
      result.innerHTML = `<span style="color:#ff5b5b">${escapeHtml(error.message)}</span>`;
    }
  });
}
