import { api } from './api.js';
import { addToCart } from './state.js';
import { money, escapeHtml } from './format.js';
import { toast } from './ui.js';

const grid = document.querySelector('[data-products-grid]');

function productCard(product) {
  return `
    <article class="product-card">
      <a href="/product.html?id=${encodeURIComponent(product.id)}">
        <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}">
      </a>
      <span class="badge">${escapeHtml(product.category)} · ${escapeHtml(product.type)}</span>
      <h3>${escapeHtml(product.name)}</h3>
      <p>${escapeHtml(product.description)}</p>
      <div class="product-row">
        <strong class="price">${money(product.price, product.currency)}</strong>
        <button class="btn primary" data-add="${escapeHtml(product.id)}">Agregar</button>
      </div>
    </article>
  `;
}

async function initShop() {
  if (!grid) return;
  const { products } = await api.products();
  grid.innerHTML = products.map(productCard).join('');
  grid.addEventListener('click', (event) => {
    const button = event.target.closest('[data-add]');
    if (!button) return;
    const product = products.find((item) => item.id === button.dataset.add);
    addToCart(product, 1);
    toast('Producto agregado al carrito.');
  });
}

initShop().catch((error) => {
  if (grid) grid.innerHTML = `<p class="notice">${escapeHtml(error.message)}</p>`;
});
