const THEME_KEY = 'neimp_theme_glow';

export function initThemeToggle() {
  const button = document.querySelector('[data-theme-toggle]');
  if (!button) return;
  button.addEventListener('click', () => {
    const enabled = document.body.classList.toggle('less-glow');
    localStorage.setItem(THEME_KEY, enabled ? 'less' : 'glow');
  });
  if (localStorage.getItem(THEME_KEY) === 'less') document.body.classList.add('less-glow');
}

document.addEventListener('DOMContentLoaded', initThemeToggle);
