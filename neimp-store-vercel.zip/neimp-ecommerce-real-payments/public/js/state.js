const CART_KEY = 'neimp_cart_v1';

export function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch {
    return [];
  }
}

export function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  window.dispatchEvent(new CustomEvent('cart:updated'));
}

export function clearCart() {
  saveCart([]);
}

export function addToCart(product, quantity = 1) {
  const cart = getCart();
  const current = cart.find((item) => item.id === product.id);
  if (current) {
    current.quantity += Number(quantity);
  } else {
    cart.push({ id: product.id, quantity: Number(quantity) });
  }
  saveCart(cart);
}

export function removeFromCart(id) {
  saveCart(getCart().filter((item) => item.id !== id));
}

export function updateQuantity(id, quantity) {
  const qty = Math.max(1, Math.min(99, Number(quantity) || 1));
  const cart = getCart().map((item) => item.id === id ? { ...item, quantity: qty } : item);
  saveCart(cart);
}

export function countCartItems() {
  return getCart().reduce((sum, item) => sum + Number(item.quantity || 0), 0);
}
