import { countCartItems } from './state.js';

export function updateCartCount() {
  const count = countCartItems();
  document.querySelectorAll('[data-cart-count]').forEach((node) => {
    node.textContent = String(count);
  });
}

export function toast(message, type = 'info') {
  let box = document.querySelector('.toast-box');
  if (!box) {
    box = document.createElement('div');
    box.className = 'toast-box';
    box.style.position = 'fixed';
    box.style.right = '16px';
    box.style.bottom = '16px';
    box.style.zIndex = '99';
    document.body.appendChild(box);
  }
  const item = document.createElement('div');
  item.textContent = message;
  item.style.marginTop = '10px';
  item.style.padding = '12px 14px';
  item.style.borderRadius = '14px';
  item.style.background = type === 'error' ? '#7f1d1d' : '#1b1b27';
  item.style.border = '1px solid rgba(255,255,255,.15)';
  item.style.boxShadow = '0 12px 35px rgba(0,0,0,.35)';
  box.appendChild(item);
  setTimeout(() => item.remove(), 3200);
}

window.addEventListener('cart:updated', updateCartCount);
document.addEventListener('DOMContentLoaded', updateCartCount);
