async function request(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) {
    throw new Error(data.error || 'Error de conexión.');
  }
  return data;
}

export const api = {
  config: () => request('/api/config'),
  products: () => request('/api/products'),
  product: (id) => request(`/api/products/${encodeURIComponent(id)}`),
  quote: (cart) => request('/api/cart/quote', { method: 'POST', body: JSON.stringify({ cart }) }),
  createPayPalOrder: (cart, customer) => request('/api/paypal/orders', {
    method: 'POST',
    body: JSON.stringify({ cart, customer })
  }),
  capturePayPalOrder: (orderID) => request(`/api/paypal/orders/${encodeURIComponent(orderID)}/capture`, {
    method: 'POST'
  }),
  order: (orderID) => request(`/api/orders/${encodeURIComponent(orderID)}`),
  adminOrders: (key) => request(`/api/admin/orders?key=${encodeURIComponent(key)}`),
  contact: (payload) => request('/api/contact', { method: 'POST', body: JSON.stringify(payload) })
};
