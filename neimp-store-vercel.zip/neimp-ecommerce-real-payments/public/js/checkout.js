import { api } from './api.js';
import { getCart, clearCart } from './state.js';
import { money, escapeHtml } from './format.js';

const summary = document.querySelector('[data-checkout-summary]');
const form = document.querySelector('[data-checkout-form]');
const paypalContainer = document.getElementById('paypal-button-container');
const statusBox = document.querySelector('[data-status]');
let config = null;

function setStatus(message) {
  if (statusBox) statusBox.textContent = message;
}

function getCustomer() {
  const data = new FormData(form);
  return {
    name: String(data.get('name') || '').trim(),
    email: String(data.get('email') || '').trim()
  };
}

function validateCustomer(customer) {
  if (!customer.name) throw new Error('Escribe tu nombre.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) throw new Error('Escribe un email válido.');
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${src}"]`);
    if (existing) return resolve();
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error('No se pudo cargar PayPal SDK.'));
    document.head.appendChild(script);
  });
}

async function renderSummary() {
  const cart = getCart();
  if (!cart.length) {
    summary.innerHTML = '<p class="notice">Tu carrito está vacío. Regresa a la tienda.</p>';
    paypalContainer.innerHTML = '';
    return null;
  }
  const { quote } = await api.quote(cart);
  summary.innerHTML = `
    ${quote.items.map((item) => `
      <div class="product-row" style="border-bottom:1px solid rgba(255,255,255,.12);padding:10px 0;">
        <span>${escapeHtml(item.name)} × ${item.quantity}</span>
        <strong>${money(Number(item.price) * item.quantity, item.currency)}</strong>
      </div>
    `).join('')}
    <h2>Total: <span class="price">${money(quote.total, quote.currency)}</span></h2>
  `;
  return quote;
}

async function initPayPal() {
  const quote = await renderSummary();
  if (!quote) return;

  config = await api.config();
  if (!config.paypalConfigured) {
    setStatus('Faltan credenciales de PayPal. Configura PAYPAL_CLIENT_ID y PAYPAL_CLIENT_SECRET en .env.');
    return;
  }

  const sdk = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(config.paypalClientId)}&currency=${encodeURIComponent(config.currency)}&intent=capture&components=buttons`;
  await loadScript(sdk);

  paypal.Buttons({
    style: { layout: 'vertical', color: 'gold', shape: 'rect', label: 'paypal' },
    async createOrder() {
      try {
        const customer = getCustomer();
        validateCustomer(customer);
        setStatus('Creando orden segura en el servidor...');
        const result = await api.createPayPalOrder(getCart(), customer);
        setStatus(`Orden creada: ${result.id}`);
        return result.id;
      } catch (error) {
        setStatus(error.message);
        throw error;
      }
    },
    async onApprove(data, actions) {
      try {
        setStatus('Capturando pago aprobado...');
        const result = await api.capturePayPalOrder(data.orderID);
        const status = result.capture?.status || result.localOrder?.status;
        if (status === 'COMPLETED') {
          clearCart();
          location.href = `/success.html?orderID=${encodeURIComponent(data.orderID)}`;
        } else {
          setStatus(`Pago procesado con estado: ${status}`);
        }
      } catch (error) {
        setStatus(`Error al capturar: ${error.message}`);
      }
    },
    onCancel() {
      location.href = '/cancel.html';
    },
    onError(error) {
      setStatus(`Error de PayPal: ${error.message || error}`);
    }
  }).render('#paypal-button-container');

  setStatus(`Modo PayPal: ${config.paypalMode}. Total validado por servidor: ${money(quote.total, quote.currency)}`);
}

if (form) {
  initPayPal().catch((error) => setStatus(error.message));
}
