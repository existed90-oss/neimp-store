import { api } from './api.js';
import { money, escapeHtml } from './format.js';

const form = document.querySelector('[data-admin-form]');
const output = document.querySelector('[data-admin-output]');

function renderOrders(orders) {
  if (!orders.length) return '<p class="muted">Todavía no hay pedidos.</p>';
  return `
    <table class="admin-table">
      <thead><tr><th>Fecha</th><th>Estado</th><th>PayPal ID</th><th>Cliente</th><th>Total</th></tr></thead>
      <tbody>
        ${orders.map((order) => `
          <tr>
            <td>${escapeHtml(new Date(order.createdAt).toLocaleString('es-MX'))}</td>
            <td>${escapeHtml(order.status)}</td>
            <td>${escapeHtml(order.paypalOrderId)}</td>
            <td>${escapeHtml(order.customer?.name || '—')}<br><span class="muted">${escapeHtml(order.customer?.email || '')}</span></td>
            <td>${order.cart ? money(order.cart.total, order.cart.currency) : '—'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

if (form) {
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const key = new FormData(form).get('key');
    output.innerHTML = '<p class="muted">Cargando pedidos...</p>';
    try {
      const { orders } = await api.adminOrders(key);
      output.innerHTML = renderOrders(orders);
    } catch (error) {
      output.innerHTML = `<p class="notice">${escapeHtml(error.message)}</p>`;
    }
  });
}
